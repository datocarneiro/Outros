Esse programa realiza uma atomação web utilizandp selenium 
buscando palavras chaves pré definidas e realizando a contagem de quantas palavras chaves foram encontradas

versão 1 
    codigo python ok 
    html e css juntos no mesmo arquivo
    resultados mostrado no formato de tabela
    